import React from 'react';

export default ({ name }) => <h1>I am {name}!</h1>;
